﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module6Assignment
{
    internal class ProductionWorker : Employee
    {
        private int _ShiftNumber;
        private float _HourlyRate;
        public ProductionWorker(int employeeNumberIn, string emplyeeNameIn, int ShiftNumberIn, float HourlyRateIn)
            :base(employeeNumberIn, emplyeeNameIn)
        {
            _ShiftNumber = ShiftNumberIn;
            _HourlyRate = HourlyRateIn;
        }
        public int ShiftNumber
        {
            get { return _ShiftNumber; }
            set { _ShiftNumber = value; }
        }

        public float HourlyRate
        {
            get { return _HourlyRate; }
            set { _HourlyRate = value; }
        }
    }
}
