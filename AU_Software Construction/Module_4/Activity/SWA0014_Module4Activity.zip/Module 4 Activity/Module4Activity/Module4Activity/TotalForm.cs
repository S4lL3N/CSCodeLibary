﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Module4Activity
{
    public partial class TotalForm : Form
    {
        public TotalForm()
        {
            InitializeComponent();
        }

        private void TotalCostLabel_Click(object sender, EventArgs e)
        {

        }
        public string TotalLabelText
        {
            get { return this.TotalCostLabel.Text; }
            set { this.TotalCostLabel.Text = value; }
        }
    }
}
